"use client";

import { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import { FilterBar, ProductGrid, useSortedList } from "@/components/product";
import { CATEGORIES, PRODUCTS } from "@/lib/products";
import { IconHanger } from "@/components/icons";

function normalizeCategory(c: string | null): string {
  return c && (CATEGORIES as readonly string[]).includes(c) ? c : "All";
}

export function CollectionClient() {
  const params = useSearchParams();
  const catParam = normalizeCategory(params.get("category"));
  const [category, setCategory] = useState(catParam);
  const [sort, setSort] = useState<"featured" | "asc" | "desc">("featured");

  /* Follow deep links (footer, collection tiles) while on the page */
  useEffect(() => {
    setCategory(catParam);
  }, [catParam]);

  const filtered = useMemo(
    () =>
      category === "All"
        ? PRODUCTS
        : PRODUCTS.filter((p) => p.category === category),
    [category]
  );
  const list = useSortedList(filtered, sort);

  return (
    <section className="mx-auto max-w-7xl px-3 py-14 sm:px-6 sm:py-20">
      <FilterBar
        category={category}
        onCategory={setCategory}
        sort={sort}
        onSort={setSort}
      />
      <div className="mb-10 mt-8 flex items-center justify-between">
        <p className="text-[11px] uppercase tracking-[0.3em] text-mist">
          {list.length} piece{list.length === 1 ? "" : "s"}
          {category !== "All" ? ` · ${category}` : " · All collections"}
        </p>
        <p className="hidden items-center gap-2 text-[10px] uppercase tracking-[0.25em] text-mist sm:flex">
          <IconHanger className="h-4 w-4 text-gold-deep" />
          Pressed to order · Shipped in 48 hours
        </p>
      </div>
      <ProductGrid products={list} />
    </section>
  );
}
