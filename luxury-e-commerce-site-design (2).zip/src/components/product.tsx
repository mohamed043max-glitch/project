"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { useStore } from "./store";
import { IconHeart, IconArrowRight } from "./icons";
import { CATEGORIES, type Product } from "@/lib/products";
import { formatGBP, cx } from "@/lib/utils";

export function ProductCard({
  product,
  index = 0,
}: {
  product: Product;
  index?: number;
}) {
  const { wishlist, toggleWishlist, notify } = useStore();
  const saved = wishlist.includes(product.slug);

  return (
    <motion.article
      initial={{ opacity: 0, y: 28 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.8, delay: (index % 4) * 0.08, ease: [0.22, 1, 0.36, 1] }}
      className="group"
    >
      <div className="relative overflow-hidden bg-parchment">
        <Link href={`/product/${product.slug}`} aria-label={product.name}>
          <div className="aspect-[3/4] overflow-hidden">
            <img
              src={product.image}
              alt={product.name}
              loading="lazy"
              className="h-full w-full object-cover transition-transform duration-[1200ms] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-[1.06]"
            />
          </div>
          {/* Hover veil + VIEW DETAILS */}
          <div className="absolute inset-x-0 bottom-0 translate-y-full bg-gradient-to-t from-charcoal/80 via-charcoal/40 to-transparent pt-14 transition-transform duration-500 ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:translate-y-0">
            <span className="btn-sheen mx-auto flex items-center justify-center gap-2 bg-gold py-3 text-[8px] font-medium uppercase tracking-[0.2em] text-charcoal sm:gap-3 sm:py-3.5 sm:text-[10px] sm:tracking-[0.3em]">
              View Details
              <IconArrowRight className="h-3 w-3 sm:h-3.5 sm:w-3.5" />
            </span>
          </div>
        </Link>

        {/* Category tag */}
        <span className="absolute left-2 top-2 max-w-[calc(100%-3rem)] truncate bg-cream/90 px-2 py-1 text-[7px] uppercase leading-relaxed tracking-[0.14em] text-ink backdrop-blur-sm sm:left-4 sm:top-4 sm:max-w-[calc(100%-5rem)] sm:px-3 sm:py-1.5 sm:text-[9px] sm:tracking-[0.3em]">
          {product.category}
        </span>

        {product.badge && (
          <span className="absolute left-2 top-[2.6rem] max-w-[calc(100%-3rem)] truncate bg-charcoal/85 px-2 py-1 text-[7px] uppercase leading-relaxed tracking-[0.14em] text-gold backdrop-blur-sm sm:left-4 sm:top-14 sm:max-w-[calc(100%-5rem)] sm:px-3 sm:py-1.5 sm:text-[9px] sm:tracking-[0.25em]">
            {product.badge}
          </span>
        )}

        {/* Wishlist */}
        <button
          onClick={() => {
            toggleWishlist(product.slug);
            notify(
              saved
                ? "Removed from your wishlist"
                : `${product.name} saved to your wishlist`
            );
          }}
          aria-label={saved ? "Remove from wishlist" : "Save to wishlist"}
          className={cx(
            "absolute right-2 top-2 flex h-7 w-7 items-center justify-center rounded-full backdrop-blur-sm transition-all duration-300 sm:right-4 sm:top-4 sm:h-9 sm:w-9",
            saved
              ? "bg-gold text-charcoal opacity-100"
              : "bg-cream/85 text-ink opacity-100 hover:bg-gold hover:text-charcoal lg:opacity-0 lg:group-hover:opacity-100"
          )}
        >
          <IconHeart className="h-4 w-4 sm:h-[18px] sm:w-[18px]" filled={saved} />
        </button>
      </div>

      <div className="mt-2 flex flex-col gap-1 sm:mt-4 sm:flex-row sm:items-start sm:justify-between sm:gap-3">
        <div className="min-w-0">
          <Link
            href={`/product/${product.slug}`}
            className="font-display text-[13px] leading-snug text-ink transition-colors group-hover:text-gold-deep sm:text-xl sm:leading-tight"
          >
            {product.name}
          </Link>
          <p className="mt-0.5 truncate text-[8px] uppercase leading-relaxed tracking-[0.16em] text-mist sm:mt-1 sm:text-[10px] sm:tracking-[0.25em]">
            {product.fabric}
          </p>
        </div>
        <p className="shrink-0 text-[13px] text-ink sm:pt-1 sm:text-[15px]">{formatGBP(product.price)}</p>
      </div>
    </motion.article>
  );
}

export function ProductGrid({ products }: { products: Product[] }) {
  return (
    <div className="products-grid">
      {products.map((p, i) => (
        <ProductCard key={p.slug} product={p} index={i} />
      ))}
    </div>
  );
}

type SortKey = "featured" | "asc" | "desc";

export function FilterBar({
  category,
  onCategory,
  sort,
  onSort,
}: {
  category: string;
  onCategory: (c: string) => void;
  sort: SortKey;
  onSort: (s: SortKey) => void;
}) {
  const tabs = ["All", ...CATEGORIES];
  return (
    <div className="flex flex-col gap-4 border-b border-line pb-5 md:flex-row md:items-center md:justify-between">
      <div className="no-scrollbar -mx-1 flex gap-1 overflow-x-auto px-1">
        {tabs.map((t) => (
          <button
            key={t}
            onClick={() => onCategory(t)}
            className={cx(
              "relative whitespace-nowrap px-4 py-2.5 text-[11px] uppercase tracking-[0.25em] transition-colors",
              category === t
                ? "text-ink"
                : "text-ink-soft hover:text-ink"
            )}
          >
            {t}
            <span
              className={cx(
                "absolute inset-x-3 bottom-0 h-px bg-gold transition-transform duration-500",
                category === t
                  ? "scale-x-100"
                  : "scale-x-0 hover:scale-x-100"
              )}
            />
          </button>
        ))}
      </div>
      <div className="flex items-center gap-3">
        <span className="text-[10px] uppercase tracking-[0.25em] text-mist">
          Order by
        </span>
        <div className="relative">
          <select
            value={sort}
            onChange={(e) => onSort(e.target.value as SortKey)}
            className="appearance-none border border-line bg-transparent py-2 pl-4 pr-10 text-[11px] uppercase tracking-[0.2em] text-ink focus:border-gold focus:outline-none"
          >
            <option value="featured">The House Edit</option>
            <option value="asc">Price · Low to High</option>
            <option value="desc">Price · High to Low</option>
          </select>
          <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-gold-deep">
            ▾
          </span>
        </div>
      </div>
    </div>
  );
}

export function useSortedList(products: Product[], sort: SortKey) {
  return useMemo(() => {
    const list = [...products];
    if (sort === "asc") list.sort((a, b) => a.price - b.price);
    if (sort === "desc") list.sort((a, b) => b.price - a.price);
    return list;
  }, [products, sort]);
}
